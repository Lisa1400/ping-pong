const Ping = require("../tabletennis");

let ping = new Ping();

describe("Even", function(){
    it("should add all even numbers within an array", function(){
        const array = [2,3,78,21,31];
        const result = ping.even(array);
        expect(result).toBe(80);
    });
});

describe("Duplicate", function(){
    it("should loop through an array and return duplicates", function(){
        const array = [2,2,3,78,21,21,31];
        const result = ping.duplicate(array);
        expect(result).toEqual([2,2, 21,21]);
    });
});

describe("Uneven", function(){
    it("should add all uneven numbers within an array", function(){
        const array = [2,3,78,21,31];
        const result = ping.uneven(array);
        expect(result).toBe(55);
    });
});

describe("Prime", function(){
    it("should loop through an array and return all prime numbers", function(){
        const array = [1,2,3,4,5];
        const result = ping.prime(array);
        expect(result).toEqual([1,2,3,5]);
    });
});
