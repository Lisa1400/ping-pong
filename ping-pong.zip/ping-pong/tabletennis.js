class Ping {
constructor(){

}
    even(array) {
        let result = 0;
        for (let i = 0; i < array.length; i++) {
            if (array[i] % 2 === 0) {
                result += array[i];
            }
        }
        return result;
    }

    duplicate(array){
        let result = [];
        for(let i = 0; i < array.length; i++){
            for(let j = i + 1; j < array.length; j++){
                if (array[i] === array[j]){
                    result.push(array[i]);
                    result.push(array[i]);
                    break;
                }
                j++;
            }
            i++;
        }
        return result;
    }


    uneven(array) {
        let result = 0;
        for (let i = 0; i < array.length; i++) {
            if (array[i] % 2 === 1) {
                result += array[i];
            }
        }
        return result;
    }

    isprime(num) {
    if (num === 1 || num === 2) {
        return true;
    }
    for (let i = 2; i < num; i++) {
        if (num % i === 0) {
            return false;
        }
        i++;
    }
    return true;
    }

    prime(array) {
    let result = [];
    for (let i = 0; i < array.length; i++) {
        if (this.isprime(array[i])){
            result.push(array[i]);
        }
    }
    return result;
    }

}

module.exports = Ping;
